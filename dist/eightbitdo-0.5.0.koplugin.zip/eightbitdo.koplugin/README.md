# 8BitDo remotes for KOReader

One plugin for the **8BitDo Zero 2** and **8BitDo Micro** in HID keyboard mode. Choose the remote in the menu; its button assignments are saved separately and restored when switching back.

## Install or upgrade

Current plugin build: **0.5.0**, shown in **8BitDo remotes → Help**. The versioned archive is `dist/eightbitdo-0.5.0.koplugin.zip`.

1. Exit KOReader. If you installed either standalone plugin, remove `koreader/plugins/zero2.koplugin` and `koreader/plugins/micro.koplugin` from the device. Keep your KOReader settings so their assignments can be imported.
2. Extract **`dist/eightbitdo.koplugin.zip`** into `koreader/plugins/`, or copy the `eightbitdo.koplugin` folder there. The resulting path must be `koreader/plugins/eightbitdo.koplugin/main.lua`.
3. Restart KOReader. If necessary, enable **8BitDo remotes** in Plugin management and restart again.
4. Connect your remote in HID keyboard mode (**K** on Micro), using your device's Bluetooth tools.
5. Open **8BitDo remotes → Remote** and select **8BitDo Zero 2** or **8BitDo Micro**. Open **Button assignments** to customize its buttons.

Only the selected profile translates input. Switching applies immediately without restarting or erasing settings. Release held buttons before switching. Both remotes use overlapping codes, so selecting the remote is manual; the plugin cannot identify the controller from the code alone.

Disable or remove the standalone plugins before using this package: their input hooks otherwise compete with the combined plugin. Disabling plugins in Plugin management requires a restart.

## Settings and migration

The menu provides a global **Enable remote mappings** toggle, a **Remote** selector, and per-remote button assignments. Resetting assignments resets only the profile whose assignments menu you opened, preserving the other profile.

On first use, the plugin copies assignments from `eightbitdo_zero2` and `eightbitdo_micro` into the new `eightbitdo_remotes` settings entry. Legacy settings remain untouched. Later starts use the combined settings.

The settings entry carries a schema number (currently 2). Settings from earlier builds are upgraded automatically and keep all assignments; the held-button repeat preference from builds before 0.5.0 is dropped. If you downgrade after a future build has saved a newer schema, this build still uses the settings it understands but does not save over them; **Help** shows a notice, and changes made in the older build are not kept.

If only Micro was enabled, Micro is selected. Otherwise Zero 2 is selected, including when both old profiles were enabled. Mapping stays disabled if all installed legacy profiles were disabled. New installations default to enabled with Zero 2 selected.

## Zero 2 defaults

| Button | Linux EV_KEY code | KOReader key | Default behavior |
| --- | ---: | --- | --- |
| D-pad up | 32 | Up | Navigate up |
| D-pad down | 46 | Down | Navigate down |
| D-pad left | 18 | Left | Navigate left |
| D-pad right | 33 | Right | Navigate right |
| Left bumper | 37 | LPgBack | Previous page |
| Right bumper | 50 | LPgFwd | Next page |
| Y | 23 | LPgBack | Previous page |
| A | 34 | Press | Select |
| X | 36 | Menu | Open menu |
| B | 35 | Back | Back/close |

## Micro defaults

The screenshot's keyboard letters are translated into Linux `EV_KEY` codes, checked against `linux/input-event-codes.h`. These are Linux codes, not numeric USB HID usage IDs.

| Micro button | Screenshot key | Linux code | Default assignment |
| --- | --- | ---: | --- |
| D-pad up | C | 46 | Up |
| D-pad down | D | 32 | Down |
| D-pad left | E | 18 | Left |
| D-pad right | F | 33 | Right |
| L | K | 37 | Previous page |
| L2 | L | 38 | Previous page |
| R | M | 50 | Next page |
| R2 | R | 19 | Next page |
| Minus (−) | N | 49 | Back |
| Plus (+) | O | 24 | Menu |
| X | H | 35 | Menu |
| A | G | 34 | Select |
| Y | I | 23 | Previous page |
| B | J | 36 | Back |
| Capture (checkerboard) | S | 31 | Ignore button |
| Star | Null | — | No keyboard event to map |

Micro's Star button has no keyboard event in the supplied profile and is omitted from the menu. Capture defaults to Ignore button and can be reassigned. If you customized Micro's keyboard profile, restore the listed letters before using this mapping.

## Available assignments

Every emitting button can be assigned **Next page**, **Previous page**, **Up**, **Down**, **Left**, **Right**, **Select**, **Back**, **Menu**, or **Ignore button**. Native KOReader keys determine behavior on the active screen or dialog. Directions follow KOReader's normal rotation handling; bumpers provide dedicated page turns.

For the full action list offered under **Gesture Manager → Tap corner**, open **8BitDo remotes → Button assignments → [button]**. The action categories appear directly in the button menu: **General**, **Device**, **Screen and lights**, **File browser**, **Reader**, and document-specific categories. Basic keys are grouped under **Native navigation keys**. This uses KOReader's own Dispatcher picker, including actions registered by other enabled plugins. The complete action picker is available, including multiple actions, numeric parameters, action sequences and QuickMenus. There is no one-action restriction. Numeric settings such as brightness and font-size changes use the same parameter controls as gestures.

Selecting an action in this picker replaces that button's native key assignment. Merely opening the picker changes nothing. Choose **Nothing** inside the picker to consume the button without an action. Selecting any native assignment again clears the gesture actions. Existing assignments, including sequences and QuickMenus, survive upgrades and edits. Resetting a remote clears its gesture actions as well as resetting its native assignments.

Action availability follows your KOReader version, device capabilities, enabled plugins, and current document or file-browser context. A button supplies no touch position or swipe distance, so touch-location actions cannot reproduce a tap at a particular screen coordinate. Use explicit numeric amounts for incremental actions. Gesture-specific controls such as “Always active” govern touch recognition and do not apply to remote buttons.


Holding a button does not repeat it: each press acts once, including custom actions. Assignments and preferences are saved automatically with KOReader's global settings.

## Requirements and troubleshooting

Your operating system and KOReader's input integration must already deliver the remote's Linux `EV_KEY` events. This plugin maps those events; it does not pair Bluetooth devices, enable Bluetooth, install drivers, or open `/dev/input/event*` devices. Android key codes and gamepad axis events are different formats.

Mappings are global and also affect physical keyboards sending the same codes. Disable **Enable remote mappings** when typing on a physical keyboard. Unrelated codes, touch input, and power buttons pass through unchanged.

If nothing works, verify keyboard mode, Bluetooth connection, and input delivery to KOReader. If up/down or X/B are reversed, check the selected remote and remove the standalone plugins. If the plugin menu is missing, check folder nesting, Plugin management, and KOReader's `crash.log`. If you still see only the old navigation choices, fully exit KOReader, overwrite `plugins/eightbitdo.koplugin` with this build, restart, and check **Help** for **v0.5.0**. Do not extract into another `eightbitdo.koplugin` folder.

To uninstall, exit KOReader, remove `plugins/eightbitdo.koplugin`, then restart. The saved settings are harmless; optionally remove `eightbitdo_remotes` from `settings.reader.lua` while KOReader is closed.

## Development and validation

Run both profiles through the regression suite:

```sh
luajit tests/run.lua
luajit tests/run.lua micro
```

Tests stub KOReader services and exercise mappings, press/release, repeat suppression, menus, settings persistence, profile switching, migration, event-map replacement, reader/file-manager lifecycle, the full tap-corner action picker, multiple action selections, custom action routing, numeric arguments, QuickMenus, action sequences, and reset. Actual Bluetooth delivery and reader/menu behavior still require hardware testing.

Build the standalone installation archive:

```sh
zip -r dist/eightbitdo.koplugin.zip eightbitdo.koplugin
```

The implementation follows KOReader's [input hook and key translation API](https://github.com/koreader/koreader/blob/master/frontend/device/input.lua) and [External Keyboard connection notifications](https://github.com/koreader/koreader/blob/master/plugins/externalkeyboard.koplugin/main.lua).

Gesture assignments follow KOReader's [Dispatcher action picker and execution API](https://github.com/koreader/koreader/blob/master/frontend/dispatcher.lua), with key bindings handled through [InputContainer](https://github.com/koreader/koreader/blob/master/frontend/ui/widget/container/inputcontainer.lua).
